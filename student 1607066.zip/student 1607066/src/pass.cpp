#include "pass.h"
void pass()
{
    int i=1;
    while(i==1)
    {
        int p;
        cout<<"\n\n\n\n\n\t\t\t\tPassword Hint: What Are you thinking?????";
        cout<<"\n\n\n\t\t\t\tEnter Your password: ";
        char *s;
        s=new char[200];
        cin>>s;
        string s1;
        s1=s;
        if(s1=="password")
            start();
        else
        {
            cout<<"\n\n\n\t\t\t\t!!!! Wrong password !!!!";
        }
        cout<<"\n\n\n\t\t\tEnter 1 For Re-open and Try again or Enter any number For Quit: ";
        cin>>i;
        delete [] s;
        system("cls");
        system("color 4F");
    }
}
