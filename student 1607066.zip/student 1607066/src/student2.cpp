#include "student2.h"
extern student2 st,st2[100];
extern int g;
student2::student2()
{
    if(!g)
    {
        system("color 4F");
        cout<<"\n\n\n\t\t\t\tPlease Make Me Sure That You Are Not A SPY !!!!";
        g=1;
    }
}
student2::~student2()
{
    //dtor
}
bool cmp(const student2& lhs, const student2& rhs)
{
  return lhs.result> rhs.result;
}
istream& operator>>(istream& cin, student2 &st)
{
    cout<<"\n\n\t\t\tEnter Roll No.:";
    cin>>st.roll;
    cout<<"\n\t\t\tEnter Name:";
    cin>>st.name;
    cout<<"\n\t\t\tEnter Department:";
    cin>>st.dept;
    cout<<"\n\t\t\tEnter Batch Name:";
    cin>>st.batch;
    cout<<"\n\t\t\tEnter Result(CGPA out of 4.00):";
    cin>>st.result;
    cout<<"\n\t\t\tEnter Hall Name:";
    cin>>st.hall;
    cout<<"\n\t\t\tEnter address:";
    cin>>st.address;
    return cin;
}
ofstream& operator<<(ofstream& file, student2 &st)
{
    file<<st.roll<<" ";
    file<<st.name<<" ";
    file<<st.dept<<" ";
    file<<st.batch<<" ";
    file<<st.result<<" ";
    file<<st.hall<<" ";
    file<<st.address<<endl;;
    return file;
}
void student2 :: write()
{
    ofstream file;
    file.open("student.txt",ios::out);
    system("cls");
    system("color FD");
    int i=1,j;
    while(i==1)
    {
        cin>>st;
        system("cls");
        printf("\n\n\t\t\tData Added Successfully");
        file<<st;
        printf("\n\n\nPress 1 for Enter another record or 2 for Main Menu:\n");
        cin>>i;
        system("cls");
        if(i==2)
        {
            file.close();
            break;
        }
    }
    //start();
}
void student2 :: append()
{
    ifstream file;
    file.open("student.txt",ios::in);
    system("cls");
    system("color F4");
    int n=0;
    string roll;
    cout<<"\n\t\t\tEnter New roll number: ";
    cin>>roll;
    ll number;
    cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    string l2;
    while(getline(file,l2))
    {
        stringstream si(l2);
        string v;
        si>>v;
        if(v==roll)
        {
            n=1;
            break;
        }
    }
    if(n==0)
    {
        ofstream file;
        file.open("student.txt",ios::app);
        cout<<"\n\n\n\t\t\tYou can add this";
        cin>>st;
        system("cls");
        cout<<"\n\n\t\t\tData Added Successfully";
        file<<st;
        cout<<"\n\n\nPress 1 for Enter another record or any key for Main Menu:\n";
        ll i;
        cin>>i;
        system("cls");
        if(i==1)
        {
            file.close();
            st.append();
        }
        else
            file.close();
    }
    else
    {
        int k;
        cout<<"\n\n\n\t\tThis roll number already exists";
        cout<<"\n\n\t\tEnter 1 for insert new data or any number for exit: ";
        cin>>k;
        if(k==1)
        {
            st.append();
        }
    }
}
void student2:: view()
{
    fstream file;
    system("cls");
    system("color 5F");
    file.open("student.txt",ios::in);
    string l2;
    while(getline(file,l2))
    {
        stringstream si(l2);
        string dummy ;
        si>>dummy;
        cout<<"\n\n\t\t\tRoll:"<<dummy<<endl<<endl;
        si>>dummy;
        cout<<"\n\t\t\tName:"<<dummy<<endl<<endl;
        si>>dummy;
        cout<<"\n\t\t\tDepartment:"<<dummy<<endl<<endl;
        si>>dummy;
        cout<<"\n\t\t\tBatch:"<<setw(8)<<dummy<<endl<<endl;
        si>>dummy;
        cout<<"\n\t\t\tResult:"<<setprecision(3)<<dummy<<endl<<endl;
        si>>dummy;
        cout<<"\n\t\t\tHall:"<<dummy<<endl<<endl;
        si>>dummy;
        cout<<"\n\t\t\tAddress:"<<dummy<<endl<<endl;
        cout<<"\n\t\t\t* * * * * * * * * * * * * * * * *";
    }
    file.close();
    cout<<"\n\n\n\t\tEnter any number for main menu: ";
    int i;
    cin>>i;
    system("cls");
    start();
}
void student2::search1()
{

    system("cls");
    system("color 6F");
    ll i=1;
    string roll;
    while (i==1)
    {
        int j=0;
        fstream file;
        file.open("student.txt",ios::in);
        file.seekg(0);
        cout<<"\n\t\tEnter Roll whose data you want to search: ";
        cin>>roll;
        cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        string l2;
        while(getline(file,l2))
        {
            stringstream si(l2);
            string sroll;
            si>>sroll;
            if(sroll==roll)
            {
                j=1;
                string dummy ;
                cout<<"\n\n\t\t\tRoll:"<<sroll<<endl<<endl;
                si>>dummy;
                cout<<"\n\t\t\tName:"<<dummy<<endl<<endl;
                si>>dummy;
                cout<<"\n\t\t\tDepartment:"<<dummy<<endl<<endl;
                si>>dummy;
                cout<<"\n\t\t\tBatch:"<<setw(8)<<dummy<<endl<<endl;
                si>>dummy;
                cout<<"\n\t\t\tResult:"<<setprecision(3)<<dummy<<endl<<endl;
                si>>dummy;
                cout<<"\n\t\t\tHall:"<<dummy<<endl<<endl;
                si>>dummy;
                cout<<"\n\t\t\tAddress:"<<dummy<<endl<<endl;
                break;
            }
        }
        if(j!=1)
        {
            cout<<"\n\n\n\t\tSorry didn't match with any data\n\n";
        }
        cout<<"\n\n\t\tTo search again enter 1 or for main menu enter any number : ";
        cin>>i;
        if(i!=1)
            file.close();
        system("cls");
    }
    start();
}
void student2:: delete1()
{
    system("color FF");
    system("cls");
    int i=1;
    while (i==1)
    {
        ll n=0;
        string roll;
        fstream file1,file2;
        file1.open("student.txt",ios::in);
        file2.open("delete.txt",ios::out);
        cout<<"\n\t\tEnter a student's roll whose data you want to delete: ";
        cin>>roll;
        string l2;
        cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        while(getline(file1,l2))
        {
            stringstream si(l2);
            string sroll;
            si>>sroll;
            if(sroll==roll)
                n=1;
            else
            {
                string dummy ;
                file2<<sroll<<" ";
                si>>dummy;
                file2<<dummy<<" ";
                si>>dummy;
                file2<<dummy<<" ";
                si>>dummy;
                file2<<dummy<<" ";
                float rr;
                si>>rr;
                file2<<rr<<" ";
                si>>dummy;
                file2<<dummy<<" ";
                si>>dummy;
                file2<<dummy<<endl;
            }
        }
        if(n==1)
        {
            cout<<"\n\n\n\t\t\t\tDelete successful..!!!\n\n\n";
        }
        else
        {
            cout<<"\n\n\n\t\tSorry Didn't match with any data\n\n\n";
        }
        file1.close();
        file2.close();
        remove("student.txt");
        rename("delete.txt","student.txt");
        cout<<"\n\n\n\tTo delete again enter 1 or for main menu enter any number : ";
        cin>>i;
        system("cls");
    }
    start();
}
void student2:: update()
{
    system("color 3F");
    system("cls");
    int i=1;
    while (i==1)
    {
        ll n=0;
        string roll1;
        fstream file1,file2;
        file1.open("student.txt",ios::in);
        file2.open("update.txt",ios::out);
        cout<<"\n\t\tEnter a student's roll whose data you want to update: ";
        cin>>roll1;
        string l2;
        cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        while(getline(file1,l2))
        {
            stringstream si(l2);
            string sroll,dummy;;
            si>>sroll;
            if(sroll==roll1)
            {
                n=1;
                cout<<"\n\n\t\t\tEnter Student's New Information:\n\n";
                roll=roll1;
                file2<<roll<<" ";
                si>>dummy;
                file2<<dummy<<" ";
                si>>dummy;
                file2<<dummy<<" ";
                si>>dummy;
                file2<<dummy<<" ";
                cout<<"\n\t\t\tEnter NEW Result(CGPA out of 4.00):";
                cin>>result;
                cout<<"\n\t\t\tEnter NEW Hall Name:";
                cin>>hall;
                cout<<"\n\t\t\tEnter NEW address:";
                cin>>address;
                file2<<result<<" "<<hall<<" "<<address<<endl;
            }
            else
            {
                string dummy ;
                file2<<sroll<<" ";
                si>>dummy;
                file2<<dummy<<" ";
                si>>dummy;
                file2<<dummy<<" ";
                si>>dummy;
                file2<<dummy<<" ";
                float rr;
                si>>rr;
                file2<<rr<<" ";
                si>>dummy;
                file2<<dummy<<" ";
                si>>dummy;
                file2<<dummy<<endl;
            }
        }
        if(n==1)
        {
            cout<<"\n\n\n\t\t\t\tUpdate successful..!!!\n\n\n";
        }
        else
        {
            cout<<"\n\n\n\t\tSorry Didn't match with any data\n\n\n";
        }
        file1.close();
        file2.close();
        remove("student.txt");
        rename("update.txt","student.txt");
        cout<<"\n\n\n\tTo update again enter 1 or for main menu enter any number : ";
        cin>>i;
        system("cls");
    }
    start();
}
void student2::sort1()
{
    fstream file;
    system("cls");
    system("color 5F");
    file.open("student.txt",ios::in);
    string l2;
    int i=0;
    while(getline(file,l2))
    {
        stringstream si(l2);
        string dummy ;
        si>>dummy;
        st2[i].roll=dummy;
        si>>dummy;
        st2[i].name=dummy;
        si>>dummy;
        st2[i].dept=dummy;
        si>>dummy;
        st2[i].batch=dummy;
        float ff;
        si>>ff;
        st2[i].result=ff;
        si>>dummy;
        st2[i].hall=dummy;
        si>>dummy;
        st2[i].address=dummy;
        i++;
    }
    file.close();
    sort(st2,st2+i,cmp);
    vector<student2>v;
    for(int x=0;x<i;x++)
        v.push_back(st2[x]);
    cout<<"\n\n\t\t Student's Information Sorted by Result\n";
    for(int j=0;j<i;j++)
    {
        cout<<"\n\n\t\t\tRoll:"<<v[j].roll;
        cout<<"\n\t\t\tName:"<<v[j].name;
        cout<<"\n\t\t\tDepartment:"<<v[j].dept;
        cout<<"\n\t\t\tBatch:"<<setw(8)<<v[j].batch;
        cout<<"\n\t\t\tResult:"<<setprecision(3)<<v[j].result;
        cout<<"\n\t\t\tHall:"<<v[j].hall;
        cout<<"\n\t\t\tAddress:"<<v[j].address<<endl;
        cout<<"\n\t\t\t* * * * * * * * * * * * * * * * *";
    }
    cout<<"\n\n\n\t\tEnter any number for main menu: ";
    int k;
    cin>>k;
    system("cls");
    start();
}
