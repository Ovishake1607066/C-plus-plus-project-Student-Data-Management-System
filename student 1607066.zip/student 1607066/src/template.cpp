#include "template.h"
template<typename t>
void show(t s)
{
    cout<<s<<endl;
}
