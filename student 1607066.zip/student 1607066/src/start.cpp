#include "start.h"
extern student2 st;
int start()
{
    system("cls");
    system("color 1F");
    int i;
    time_t t=time(NULL);
    cout<<"\n\n  Exclusive By OVISHAKE SEN\t\t\t\t\t\t\t\t   "<<ctime(&t);
    cout<<"\n\t\t\t\t~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~";
    cout<<"\n    WELCOME\t\t\t~ Khulna University of Engineering and Technology ~\t\t\t WELCOME";
    cout<<"\n\t\t\t\t~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~";
    cout<<"\n\n\t\t\t\t\t* * * * * * * * * * * * * * * * * * * *";
    cout<<"\n\t\t\t\t\t* Student Database management System  *";
    cout<<"\n\t\t\t\t\t* * * * * * * * * * * * * * * * * * * *";
    cout<<"\n\n\n\n\t\t\t\t\tWhat Do you Want To Do?????";
    cout<<"\n\n\t\t\t\t\t1.Insert New Student's Data";
    cout<<"\n\n\t\t\t\t\t2.Update Any student's Data";
    cout<<"\n\n\t\t\t\t\t3.Search Any Student's Data";
    cout<<"\n\n\t\t\t\t\t4.Delete any Student's Data";
    cout<<"\n\n\t\t\t\t\t5.View All Student's Data";
    cout<<"\n\n\t\t\t\t\t6.Sort All Student's Data According To Result";
    cout<<"\n\n\t\t\t\t\t7.!!!!!!!!!! Quit !!!!!!!!!\n\t\t\t";
    cout<<"\n\n\t\t\t\t\tPlease Enter a choice:";
    cin>>i;
    if(i==1)
    {
        int n;
        system("cls");
        system("color F3");
        printf("\n\n\t\tDo you want to keep your current data??\n\n\t\t\t1.Yes\n\t\t\t2.No\n\n\n\t\t\tSelect your choice: ");
        cin>>n;
        if(n==1)
        {
            st.append();
        }
        else if(n==2)
        {
            st.write();
        }
        else
        {
            cout<<"\n\n\t\t\t\tWrong Selection!!!!!!!!";
            start();
        }
        system("cls");
        start();
    }
    else if(i==2)
    {
        st.update();
    }
    else if(i==3)
    {
        st.search1();
    }
    else if(i==4)
    {
        st.delete1();
    }
    else if(i==5)
    {
        st.view();
    }
    else if(i==6)
    {
        st.sort1();
    }
    else
    {
        system("cls");
        system("color CF");
        printf("\n\n\t\t\t\tAre you Really want to Quit??????");
    }
}
