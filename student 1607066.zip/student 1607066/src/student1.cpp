#include "student1.h"

student1::student1()
{
    //ctor
}

student1::~student1()
{
    //dtor
}
