#include "namespace.h"
namespace name
{
void intro()
{
    //extra<string>e;
    show("\n\n\t\t\t\t\tCreated By OVISHAKE SEN");
    show("\n\n\n\n\n\t\t\t\t\tThanks For Your Visit\n\n\n\n\n");
}
}
