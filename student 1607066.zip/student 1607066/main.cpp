#include <iostream>
#include "pass.h"
#include "student2.h"
#include "extra.h"
#include "namespace.h"
using namespace std;
int g;
student2 st,st2[100];
int main()
{
    pass();
    system("cls");
    system("color 4F");
    name::intro();
}
