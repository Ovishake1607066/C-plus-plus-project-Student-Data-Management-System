#ifndef START_H_INCLUDED
#define START_H_INCLUDED
#include "student2.h"
#include "student1.h"
#define ll long long
int start();
#endif // START_H_INCLUDED
