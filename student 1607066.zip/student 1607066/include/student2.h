#ifndef STUDENT2_H
#define STUDENT2_H
#include "student1.h"
#define ll long long
#include "start.h"
class student2:public student1
{
public:
    student2();
    virtual ~student2();
    void write();
    void append();
    void view();
    void search1();
    void delete1();
    void update();
    void sort1();
    friend istream& operator>>(istream& cin, student2 &st);
    friend ofstream& operator<<(ofstream& cout, student2 &st);
};
#endif // STUDENT2_H
