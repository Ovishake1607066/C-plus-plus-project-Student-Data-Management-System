#ifndef PASS_H_INCLUDED
#define PASS_H_INCLUDED
#include<bits/stdc++.h>
#include "start.h"
using namespace std;
void pass();
#endif // PASS_H_INCLUDED
