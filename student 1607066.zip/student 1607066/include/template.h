#ifndef TEMPLATE_H_INCLUDED
#define TEMPLATE_H_INCLUDED
#include<bits/stdc++.h>
using namespace std;
template<typename t>
void show(t s);

#endif // TEMPLATE_H_INCLUDED
