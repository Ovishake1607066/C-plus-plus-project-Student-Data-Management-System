#ifndef NAMESPACE_H_INCLUDED
#define NAMESPACE_H_INCLUDED
#include<bits/stdc++.h>
using namespace std;
#include "extra.h"
namespace name
{
void intro();
}

#endif // NAMESPACE_H_INCLUDED
