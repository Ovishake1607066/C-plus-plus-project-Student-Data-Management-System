#ifndef STUDENT1_H
#define STUDENT1_H
#include<bits/stdc++.h>
using namespace std;
class student1
{
public:
    student1();
    virtual ~student1();
    float result;
protected:
    string roll;
    string name;
    string dept;
    string batch;
    string hall;
    string address;
};

#endif // STUDENT1_H
